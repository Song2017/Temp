.. toctree::
    :maxdepth: 2
    :hidden:

applicationinsights.requests module
===================================

WSGIApplication class
---------------------
.. autoclass:: applicationinsights.requests.WSGIApplication
    :members:
    :member-order: groupwise
    :inherited-members:
