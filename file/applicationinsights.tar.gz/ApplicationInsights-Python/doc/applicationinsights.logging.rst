.. toctree::
    :maxdepth: 2
    :hidden:

applicationinsights.logging module
==================================

enable function
---------------
.. autofunction:: applicationinsights.logging.enable

LoggingHandler class
--------------------
.. autoclass:: applicationinsights.logging.LoggingHandler
    :members:
    :member-order: groupwise
    :inherited-members:
