applicationinsights module
==========================

.. toctree::
    :maxdepth: 1

    applicationinsights.channel
    applicationinsights.logging
    applicationinsights.requests
    applicationinsights.django
    applicationinsights.exceptions

TelemetryClient class
----------------------
.. autoclass:: applicationinsights.TelemetryClient
    :members:
    :member-order: groupwise
    :inherited-members:
