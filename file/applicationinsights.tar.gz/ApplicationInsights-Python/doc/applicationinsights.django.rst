.. toctree::
    :maxdepth: 2
    :hidden:

applicationinsights.django module
=================================

ApplicationInsightsMiddleware class
-----------------------------------
.. autoclass:: applicationinsights.django.ApplicationInsightsMiddleware
    :members:
    :member-order: groupwise
    :inherited-members:

LoggingHandler class
--------------------
.. autoclass:: applicationinsights.django.LoggingHandler

create_client function
----------------------
.. autofunction:: applicationinsights.django.create_client
