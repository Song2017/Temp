.. toctree::
    :maxdepth: 2
    :hidden:

applicationinsights.exceptions module
=====================================

enable function
---------------
.. autofunction:: applicationinsights.exceptions.enable
