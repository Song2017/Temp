class DependencySourceType(object):
    """Data contract class for type DependencySourceType."""
    # Enumeration value undefined
    undefined = 0
    
    # Enumeration value aic
    aic = 1
    
    # Enumeration value apmc
    apmc = 2
    

